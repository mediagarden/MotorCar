package com.samsung.baymax.motorcar;

public interface ICameraCallback {
    public void cameraCallback(byte[] photo);
}
