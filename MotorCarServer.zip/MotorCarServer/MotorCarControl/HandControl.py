# encoding='utf-8'
from MotorCarControl.ConcurrentQueue import ConcurrentQueue
from MotorCarControl.HandDriver import HandDriver
import threading
import logging
from time import ctime, sleep


class HandControl:
    def __init__(self, logging):
        self.queue = ConcurrentQueue(-1)
        self.driver = HandDriver(logging)
        self.logging = logging
        self.tag = "Head Control"
        self.SLEEP_TIME = 0.1

    def run(self):
        self.serverThread = threading.Thread(target=self.__runServer)
        self.serverThread.setDaemon(True)
        self.serverThread.start()

    def __runServer(self):
        self.driver.HandRecovery()
        while True:
            if (self.queue.empty()):
                sleep(self.SLEEP_TIME)
            else:
                self.__exeControlMessage(self.queue.get())
                sleep(self.SLEEP_TIME)

    def __exeControlMessage(self, msg):
        # TODO:CONTROL
        self.driver.HandControl(msg)
        self.logging.info(self.tag + ": Execute The Command!")
        return

    def putControlMessage(self, msg):
        # TODO:CHECK
        self.queue.put(msg)
        self.logging.info(self.tag + ": Put Message!")
        return True
