package com.samsung.baymax.utils;

public class Config {
    public static final String HostIP = "192.168.254.1";
    public static final int MotorCarPort = 10000;
    public static final int CameraPort = 10001;
/*    public static final String standBy = "STANDBY";
    public static final String underControl = "CONTROL";*/
}
