package com.samsung.baymax;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Notification;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.samsung.baymax.motorcar.MotorCar;
import com.samsung.baymax.motorcar.MyClient;
import com.samsung.baymax.utils.MotorCarControl;

import java.text.DecimalFormat;

public class BayMaxActivity extends Activity {

    private final String TAG = BayMaxActivity.class.getSimpleName();
    private TextView connectDevice;

    private TextView showDirection;
    private TextView holdOn;
    private TextView underControl;

    private LinearLayout linearLayout;
    private LinearLayout firstButton;
    private LinearLayout secondButton;
    private LinearLayout thirdButton;
    private boolean isConnected = false;
    private int cnt = 0;

    DrawView drawView1;// = new DrawView(this, 25, 130, 25);;
    DrawView drawView2;// = new DrawView(this, 25, 130, 25);
    DrawView drawView3;

    private float savedDrawView1Y = 130;
    private float savedDrawView2Y = 130;
    private float savedDrawView3Y = 130;


    public Handler baymaxHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 1000) {
                isConnected = true;
                Toast.makeText(getBaseContext(), "设备连接成功", Toast.LENGTH_LONG).show();
                if (isConnected)
                    connectDevice.setOnClickListener(null);
            }/* else if (msg.what == 1001) {
                showDirection.setText(getString(R.string.direction_info) + " angle: " + stringFomate(myClient.motorCarControl.angle) + " , range: " + stringFomate(myClient.motorCarControl.range) + " , x: " + stringFomate(myClient.motorCarControl.x) + ", y: "
                        + stringFomate(myClient.motorCarControl.y));
                //    Toast.makeText(getBaseContext(), "MyClient run: angle: " + myClient.motorCarControl.angle + " , range: " +  myClient.motorCarControl.range + " , x: " + myClient.motorCarControl.x + ", y: "
                //           +  myClient.motorCarControl.y + " , z: " +  myClient.motorCarControl.z + " , h: " + myClient.motorCarControl.h, Toast.LENGTH_SHORT).show();
            }*/
        }
    };

    private String stringFomate(double num) {
        String str = "";
        DecimalFormat df = new DecimalFormat("0.00");
        return str + df.format(num);
    }

    private MyClient myClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bay_max);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);// 横屏

        linearLayout = findViewById(R.id.root);
        connectDevice = findViewById(R.id.button_connect_to_device);
        showDirection = findViewById(R.id.show_direction);

        firstButton = findViewById(R.id.layout_first_button);
        secondButton = findViewById(R.id.layout_second_button);
        thirdButton = findViewById(R.id.layout_third_button);
        holdOn = findViewById(R.id.hold_on_button);
        underControl = findViewById(R.id.under_control_button);

        connectDevice.setOnClickListener(connectDeviceListener);
        holdOn.setOnClickListener(holdOnListener);
        underControl.setOnClickListener(underControlListener);

        //左侧方向，速度码盘
        final DrawView drawView = new DrawView(this, 125, 125, 50);
        myClient = MyClient.getInstance(getApplicationContext(), baymaxHandler);
        myClient.motorCarControl.angle = 0;
        myClient.motorCarControl.range = 0;
        myClient.motorCarControl.mode = "STANDBY";
        if (null != savedInstanceState) {
            Log.e(TAG, "onCreate Recovery SavedInstanceState");
            myClient.motorCarControl.mode = savedInstanceState.getString("myClient.motorCarControl.mode");
            savedDrawView1Y = savedInstanceState.getFloat("drawView1.Y", savedDrawView1Y);
            savedDrawView2Y = savedInstanceState.getFloat("drawView2.Y", savedDrawView2Y);
            savedDrawView3Y = savedInstanceState.getFloat("drawView3.Y", savedDrawView3Y);
            Log.e(TAG, myClient.motorCarControl.mode + Float.toString(savedDrawView1Y) + "/" + Float.toString(savedDrawView2Y)+ "/" + Float.toString(savedDrawView3Y));
        }
        firstButton.setEnabled(true);
        secondButton.setEnabled(true);
        thirdButton.setEnabled(true);
        final double maxLength = getBaseContext().getResources().getDisplayMetrics().density * 75;
        final double para = getBaseContext().getResources().getDisplayMetrics().density * 125;
        drawView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_MOVE:
                        drawView.currentX = event.getX();
                        drawView.currentY = event.getY();
                        float circleX = drawView.currentX > drawView.getInitX() ? (drawView.currentX - drawView.getInitX()) : (drawView.getInitX() - drawView.currentX);
                        float circleY = drawView.currentY > drawView.getInitY() ? (drawView.currentY - drawView.getInitY()) : (drawView.getInitY() - drawView.currentY);
                        float radius = drawView.getInitX() - drawView.getRadius();
                        if (circleX * circleX + circleY * circleY > radius * radius) {
                            float length = (float) Math.sqrt((double) (circleX * circleX + circleY * circleY));
                            circleX = (radius * circleX) / length;
                            circleY = (radius * circleY) / length;
                            drawView.currentX = drawView.currentX > drawView.getInitX() ? (drawView.getInitX() + circleX) : (drawView.getInitX() - circleX);
                            drawView.currentY = drawView.currentY > drawView.getInitY() ? (drawView.getInitY() + circleY) : (drawView.getInitY() - circleY);
                        }
                        double x = drawView.currentX - para;
                        double y = drawView.currentY - para;
                        double z = Math.sqrt(x * x + y * y);
                        myClient.motorCarControl.range = z / maxLength;

                        if (x == 0 && y < 0) {
                            myClient.motorCarControl.angle = 0;
                        } else if (x > 0 && y < 0) {
                            myClient.motorCarControl.angle = (Math.atan(-x / y)) / (2 * Math.PI);
                            Log.i(TAG, "circle length: atan angle: " + myClient.motorCarControl.angle + ", x: " + x + " y: " + y);
                        } else if (y == 0 && x > 0) {
                            myClient.motorCarControl.angle = 90 / 360;
                        } else if (x > 0 && y > 0) {
                            myClient.motorCarControl.angle = 0.5 - Math.atan(x / y) / (2 * Math.PI);
                        } else if (x == 0 && y > 0) {
                            myClient.motorCarControl.angle = 180 / 360;
                        } else if (x < 0 && y > 0) {
                            myClient.motorCarControl.angle = 0.5 + Math.atan(-x / y) / (2 * Math.PI);
                        } else if (x < 0 && y == 0) {
                            myClient.motorCarControl.angle = 270 / 360;
                        } else if (x < 0 && y < 0) {
                            myClient.motorCarControl.angle = 1 - Math.atan(x / y) / (2 * Math.PI);
                        }
                        showDirection.setText("angle:" + stringFomate(myClient.motorCarControl.angle) + ", range:" + stringFomate(myClient.motorCarControl.range) + ", x:" + stringFomate(myClient.motorCarControl.x) + ", y:"
                                + stringFomate(myClient.motorCarControl.y) + ", z:"+stringFomate(myClient.motorCarControl.z)+", "  + (myClient.motorCarControl.mode.equals("STANDBY") ? "待机" : "控制"));
                        Log.i(TAG, "circle length: angle: " + myClient.motorCarControl.angle + ", x: " + x + " y: " + y + " z: " + z + " current X: " + drawView.currentX + " currentY: " + drawView.currentY);
                        //通过draw组件重绘
                        drawView.invalidate();
                        break;
                    case MotionEvent.ACTION_UP:
                        drawView.currentX = drawView.getInitX();
                        drawView.currentY = drawView.getInitY();
                        myClient.motorCarControl.angle = 0;
                        myClient.motorCarControl.range = 0;
                        showDirection.setText("angle:" + stringFomate(myClient.motorCarControl.angle) + ", range:" + stringFomate(myClient.motorCarControl.range) + ", x:" + stringFomate(myClient.motorCarControl.x) + ", y:"
                                + stringFomate(myClient.motorCarControl.y) + ", z:"+stringFomate(myClient.motorCarControl.z)+", "  + (myClient.motorCarControl.mode.equals("STANDBY") ? "待机" : "控制"));
                        //通过draw组件重绘
                        drawView.invalidate();
                        break;
                }
                return true;
            }
        });
        linearLayout.addView(drawView);
        addFirstSquare();
        addSecondSquare();
        addThirdSquare();

        showDirection.setText("angle:" + stringFomate(myClient.motorCarControl.angle) + ", range:" + stringFomate(myClient.motorCarControl.range) + ", x:" + stringFomate(myClient.motorCarControl.x) + ", y:"
                + stringFomate(myClient.motorCarControl.y) + ", z:"+stringFomate(myClient.motorCarControl.z)+", "  + (myClient.motorCarControl.mode.equals("STANDBY") ? "待机" : "控制"));
    }

    public void addFirstSquare() {
        drawView1 = new DrawView(this, 25, 130, 25);
        drawView1.currentY = savedDrawView1Y * drawView1.scale;
        drawView1.invalidate();
        myClient.motorCarControl.x = 0;
        myClient.motorCarControl.x = (getBaseContext().getResources().getDisplayMetrics().density * 130 - drawView1.currentY) / (getBaseContext().getResources().getDisplayMetrics().density * 105);
        showDirection.setText("angle:" + stringFomate(myClient.motorCarControl.angle) + ", range:" + stringFomate(myClient.motorCarControl.range) + ", x:" + stringFomate(myClient.motorCarControl.x) + ", y:"
                + stringFomate(myClient.motorCarControl.y) + ", z:"+stringFomate(myClient.motorCarControl.z)+", "  + (myClient.motorCarControl.mode.equals("STANDBY") ? "待机" : "控制"));
        drawView1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_MOVE:
                        if (myClient.motorCarControl.mode.equals("CONTROL")) {
                        drawView1.currentY = event.getY();
                        if (drawView1.currentY < drawView1.getRadius())
                            drawView1.currentY = drawView1.getRadius();
                        else if (drawView1.currentY > getBaseContext().getResources().getDisplayMetrics().density * 260 - drawView1.getRadius())
                            drawView1.currentY = getBaseContext().getResources().getDisplayMetrics().density * 260 - drawView1.getRadius();
                        myClient.motorCarControl.x = (getBaseContext().getResources().getDisplayMetrics().density * 130 - drawView1.currentY) / (getBaseContext().getResources().getDisplayMetrics().density * 105);
                            showDirection.setText("angle:" + stringFomate(myClient.motorCarControl.angle) + ", range:" + stringFomate(myClient.motorCarControl.range) + ", x:" + stringFomate(myClient.motorCarControl.x) + ", y:"
                                    + stringFomate(myClient.motorCarControl.y) + ", z:"+stringFomate(myClient.motorCarControl.z)+", "  + (myClient.motorCarControl.mode.equals("STANDBY") ? "待机" : "控制"));
                        drawView1.invalidate();
                    }
                        break;
            /*        case MotionEvent.ACTION_UP:
                        drawView.currentY = drawView.getInitY();
                        myClient.motorCarControl.x = 0;
                        showDirection.setText(" angle: " + stringFomate(myClient.motorCarControl.angle) + " , range: " + stringFomate(myClient.motorCarControl.range) + " , x: " + stringFomate(myClient.motorCarControl.x) + ", y: "
                                + stringFomate(myClient.motorCarControl.y));
                        //通过draw组件重绘
                        drawView.invalidate();
                        break;*/
                }
                return true;
            }
        });
        firstButton.addView(drawView1);
    }

    public void addSecondSquare() {
        drawView2 = new DrawView(this, 25, 130, 25);
        drawView2.currentY = savedDrawView2Y * drawView2.scale;
        drawView2.invalidate();
        myClient.motorCarControl.y = 0;
        myClient.motorCarControl.y = (getBaseContext().getResources().getDisplayMetrics().density * 130 - drawView2.currentY) / (getBaseContext().getResources().getDisplayMetrics().density * 105);
        showDirection.setText("angle:" + stringFomate(myClient.motorCarControl.angle) + ", range:" + stringFomate(myClient.motorCarControl.range) + ", x:" + stringFomate(myClient.motorCarControl.x) + ", y:"
                + stringFomate(myClient.motorCarControl.y) + ", z:"+stringFomate(myClient.motorCarControl.z)+", "  + (myClient.motorCarControl.mode.equals("STANDBY") ? "待机" : "控制"));

        drawView2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_MOVE:
                        if (myClient.motorCarControl.mode.equals("CONTROL")) {
                            //    drawView.currentX = event.getX();
                            drawView2.currentY = event.getY();
                            if (drawView2.currentY < drawView2.getRadius())
                                drawView2.currentY = drawView2.getRadius();
                            else if (drawView2.currentY > getBaseContext().getResources().getDisplayMetrics().density * 260 - drawView2.getRadius())
                                drawView2.currentY = getBaseContext().getResources().getDisplayMetrics().density * 260 - drawView2.getRadius();
                            myClient.motorCarControl.y = (getBaseContext().getResources().getDisplayMetrics().density * 130 - drawView2.currentY) / (getBaseContext().getResources().getDisplayMetrics().density * 105);
                            showDirection.setText("angle:" + stringFomate(myClient.motorCarControl.angle) + ", range:" + stringFomate(myClient.motorCarControl.range) + ", x:" + stringFomate(myClient.motorCarControl.x) + ", y:"
                                    + stringFomate(myClient.motorCarControl.y) + ", z:"+stringFomate(myClient.motorCarControl.z)+", "  + (myClient.motorCarControl.mode.equals("STANDBY") ? "待机" : "控制"));
                            drawView2.invalidate();
                        }
                        break;
                /*    case MotionEvent.ACTION_UP:
                        drawView.currentY = drawView.getInitY();
                        myClient.motorCarControl.y = 0;
                        showDirection.setText(" angle: " + stringFomate(myClient.motorCarControl.angle) + " , range: " + stringFomate(myClient.motorCarControl.range) + " , x: " + stringFomate(myClient.motorCarControl.x) + ", y: "
                                + stringFomate(myClient.motorCarControl.y));
                        //通过draw组件重绘
                        drawView.invalidate();
                        break;*/
                }
                return true;
            }
        });
        secondButton.addView(drawView2);
    }

    public void addThirdSquare() {
        drawView3 = new DrawView(this, 25, 130, 25);
        drawView3.currentY = savedDrawView3Y * drawView3.scale;
        drawView3.invalidate();
        myClient.motorCarControl.z = 0;
        myClient.motorCarControl.z = (getBaseContext().getResources().getDisplayMetrics().density * 130 - drawView3.currentY) / (getBaseContext().getResources().getDisplayMetrics().density * 105);
        showDirection.setText("angle:" + stringFomate(myClient.motorCarControl.angle) + ", range:" + stringFomate(myClient.motorCarControl.range) + ", x:" + stringFomate(myClient.motorCarControl.x) + ", y:"
                + stringFomate(myClient.motorCarControl.y) + ", z:"+stringFomate(myClient.motorCarControl.z)+", "  + (myClient.motorCarControl.mode.equals("STANDBY") ? "待机" : "控制"));

        drawView3.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_MOVE:
                        if (myClient.motorCarControl.mode.equals("CONTROL")) {
                            //    drawView.currentX = event.getX();
                            drawView3.currentY = event.getY();
                            if (drawView3.currentY < drawView3.getRadius())
                                drawView3.currentY = drawView3.getRadius();
                            else if (drawView3.currentY > getBaseContext().getResources().getDisplayMetrics().density * 260 - drawView3.getRadius())
                                drawView3.currentY = getBaseContext().getResources().getDisplayMetrics().density * 260 - drawView3.getRadius();
                            myClient.motorCarControl.z = (getBaseContext().getResources().getDisplayMetrics().density * 130 - drawView3.currentY) / (getBaseContext().getResources().getDisplayMetrics().density * 105);
                            showDirection.setText("angle:" + stringFomate(myClient.motorCarControl.angle) + ", range:" + stringFomate(myClient.motorCarControl.range) + ", x:" + stringFomate(myClient.motorCarControl.x) + ", y:"
                                    + stringFomate(myClient.motorCarControl.y) + ", z:"+stringFomate(myClient.motorCarControl.z)+", "  + (myClient.motorCarControl.mode.equals("STANDBY") ? "待机" : "控制"));
                            drawView3.invalidate();
                        }
                        break;
                /*    case MotionEvent.ACTION_UP:
                        drawView.currentY = drawView.getInitY();
                        myClient.motorCarControl.y = 0;
                        showDirection.setText(" angle: " + stringFomate(myClient.motorCarControl.angle) + " , range: " + stringFomate(myClient.motorCarControl.range) + " , x: " + stringFomate(myClient.motorCarControl.x) + ", y: "
                                + stringFomate(myClient.motorCarControl.y));
                        //通过draw组件重绘
                        drawView.invalidate();
                        break;*/
                }
                return true;
            }
        });
        thirdButton.addView(drawView3);
    }

    private void showAlertDialog() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("是否退出？");
        dialog.setCancelable(true);
        dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(), "退出应用", Toast.LENGTH_LONG);
                finish();
            }
        });
        dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        dialog.show();
    }

    @Override
    public void onBackPressed() {
        showAlertDialog();
        return;
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        Log.e(TAG, "onSaveInstanceState");
        savedInstanceState.putString("myClient.motorCarControl.mode", myClient.motorCarControl.mode);
        savedInstanceState.putFloat("drawView1.Y", drawView1.currentY / drawView1.scale);
        savedInstanceState.putFloat("drawView2.Y", drawView2.currentY / drawView2.scale);
        savedInstanceState.putFloat("drawView3.Y", drawView3.currentY / drawView3.scale);
        Log.e(TAG, myClient.motorCarControl.mode + Float.toString(drawView1.currentY / drawView1.scale) + "/" + Float.toString(drawView2.currentY / drawView2.scale) + "/" + Float.toString(drawView3.currentY / drawView3.scale));

        super.onSaveInstanceState(savedInstanceState);
    }

    //点击连接设备按钮连接到WIFI
    private View.OnClickListener connectDeviceListener = new View.OnClickListener() {
        @Override
        public void onClick(View var1) {
            final SocketSyncTask socketSyncTask = new SocketSyncTask();
            socketSyncTask.execute(500);
        }
    };

    //点击待机设备按钮连接到WIFI
    private View.OnClickListener holdOnListener = new View.OnClickListener() {
        @Override
        public void onClick(View var1) {
            myClient.motorCarControl.mode = "STANDBY";
            drawView1.currentY = drawView1.getInitY();
            drawView1.invalidate();
            drawView2.currentY = drawView2.getInitY();
            drawView2.invalidate();
            drawView3.currentY=drawView3.getInitY();
            drawView3.invalidate();
            firstButton.setEnabled(false);
            secondButton.setEnabled(false);
            thirdButton.setEnabled(false);
            Toast.makeText(getBaseContext(), "待机", Toast.LENGTH_LONG).show();
            myClient.motorCarControl.x = (getBaseContext().getResources().getDisplayMetrics().density * 130 - drawView1.currentY) / (getBaseContext().getResources().getDisplayMetrics().density * 105);
            myClient.motorCarControl.y = (getBaseContext().getResources().getDisplayMetrics().density * 130 - drawView2.currentY) / (getBaseContext().getResources().getDisplayMetrics().density * 105);
            myClient.motorCarControl.z = (getBaseContext().getResources().getDisplayMetrics().density * 130 - drawView3.currentY) / (getBaseContext().getResources().getDisplayMetrics().density * 105);
            showDirection.setText("angle:" + stringFomate(myClient.motorCarControl.angle) + ", range:" + stringFomate(myClient.motorCarControl.range) + ", x:" + stringFomate(myClient.motorCarControl.x) + ", y:"
                    + stringFomate(myClient.motorCarControl.y) + ", z:"+stringFomate(myClient.motorCarControl.z)+", "  + (myClient.motorCarControl.mode.equals("STANDBY") ? "待机" : "控制"));
        }
    };
    //点击控制设备按钮连接到WIFI
    private View.OnClickListener underControlListener = new View.OnClickListener() {
        @Override
        public void onClick(View var1) {
            myClient.motorCarControl.mode = "CONTROL";
            drawView1.currentY = drawView1.getInitY();
            drawView1.invalidate();
            drawView2.currentY = drawView2.getInitY();
            drawView2.invalidate();
            drawView3.currentY=drawView3.getInitY();
            drawView3.invalidate();
            firstButton.setEnabled(true);
            secondButton.setEnabled(true);
            thirdButton.setEnabled(true);
            Toast.makeText(getBaseContext(), "控制", Toast.LENGTH_LONG).show();
            myClient.motorCarControl.x = (getBaseContext().getResources().getDisplayMetrics().density * 130 - drawView1.currentY) / (getBaseContext().getResources().getDisplayMetrics().density * 105);
            myClient.motorCarControl.y = (getBaseContext().getResources().getDisplayMetrics().density * 130 - drawView2.currentY) / (getBaseContext().getResources().getDisplayMetrics().density * 105);
            myClient.motorCarControl.z = (getBaseContext().getResources().getDisplayMetrics().density * 130 - drawView3.currentY) / (getBaseContext().getResources().getDisplayMetrics().density * 105);
            showDirection.setText("angle:" + stringFomate(myClient.motorCarControl.angle) + ", range:" + stringFomate(myClient.motorCarControl.range) + ", x:" + stringFomate(myClient.motorCarControl.x) + ", y:"
                    + stringFomate(myClient.motorCarControl.y) + ", z:"+stringFomate(myClient.motorCarControl.z)+", "  + (myClient.motorCarControl.mode.equals("STANDBY") ? "待机" : "控制"));
        }
    };

    private class SocketSyncTask extends AsyncTask<Integer, Integer, Integer> {
        SocketSyncTask socketSyncTask;

        public SocketSyncTask getInstatcnce() {
            if (socketSyncTask == null) {
                socketSyncTask = new SocketSyncTask();
            }
            return socketSyncTask;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Log.i(TAG, "SocketSyncTask onPreExecute");
            myClient.connectToMotorCar();
        }

        @Override
        protected Integer doInBackground(Integer... params) {
            Log.i(TAG, "SocketSyncTask doInBackground");
            return 1;
        }

        @Override
        protected void onPostExecute(Integer usage) {
            super.onPostExecute(usage);
            Log.i(TAG, "SocketSyncTask onPostExecute");
        }
    }

    private class PhotoSyncTask extends AsyncTask<Integer, Integer, Integer> {
        PhotoSyncTask photoSyncTask;

        public PhotoSyncTask getInstance() {
            if (photoSyncTask == null) {
                photoSyncTask = new PhotoSyncTask();
            }
            return photoSyncTask;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Log.i(TAG, "PhotoSyncTask onPreExecute");
            myClient.takePhoto();
        }

        @Override
        protected Integer doInBackground(Integer... params) {
            Log.i(TAG, "PhotoSyncTask doInBackground");
            return 1;
        }

        @Override
        protected void onPostExecute(Integer usage) {
            super.onPostExecute(usage);
            Log.i(TAG, "PhotoSyncTask onPostExecute");
        }
    }
}
