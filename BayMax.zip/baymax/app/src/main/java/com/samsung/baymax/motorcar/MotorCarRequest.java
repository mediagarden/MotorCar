package com.samsung.baymax.motorcar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;

public class MotorCarRequest {

    private static int message_id = 1;

    private double angle;  //角度
    private double range;  //幅度
    private String mode;   //模式
    private double x;       //上下
    private double y;       //
    private double z;       //抓放

    public void setCarControl(double d, double e) {
        BigDecimal bg = new BigDecimal(d);
        this.angle = bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
        bg = new BigDecimal(e);
        this.range = bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    public void setHandControl(String mode, double x, double y,double z) {
        this.mode = mode;
        if (this.mode.equals("STANDBY")) {
            this.x = 0.0;
            this.y = 0.0;
            this.z = 0.0;
        } else {
            BigDecimal bg = new BigDecimal(x);
            this.x = bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
            bg = new BigDecimal(y);
            this.y = bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
            bg = new BigDecimal(z);
            this.z = bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
        }
    }

    public String Serialize() {
        JSONObject json = new JSONObject();
        try {
            json.put("MESSAGE_ID", message_id++);
            JSONObject carControl = new JSONObject();
            carControl.put("ANGLE", angle);
            carControl.put("RANGE", range);
            json.put("CAR_CONTROL", carControl);

            JSONObject handControl = new JSONObject();
            JSONArray handAngle = new JSONArray();
            handAngle.put(x);
            handAngle.put(y);
            handAngle.put(z);
            handControl.put("MODE", this.mode);
            handControl.put("ANGLE", handAngle);
            json.put("HANDS_CONTROL", handControl);
        } catch (JSONException e) {
            e.getStackTrace();
        }

        return json.toString();
    }
}
