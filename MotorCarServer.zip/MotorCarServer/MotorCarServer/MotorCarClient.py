# -*- coding:utf-8 -*-
from socket import *
from time import ctime, sleep


# 模拟APP客户端控制小车
class MotorCarClient:
    clientMessage = '''{"MESSAGE_ID":11111,"CAR_CONTROL":{"ANGLE":180,"RANGE":0.85},"HANDS_CONTROL":[0,1,0,0]}'''

    def __init__(self, config, logging):
        self.MESSAGE_LEN = 256
        self.SLEEP_TIME = 0.1
        self.tag = "MotorCar Client"
        self.logging = logging
        clientConnection = socket(AF_INET, SOCK_STREAM)
        clientConnection.connect((config["IP"], config["Port"]))
        try:
            while True:
                clientConnection.send(
                    bytes(MotorCarClient.clientMessage.ljust(self.MESSAGE_LEN, ' '), encoding='utf-8'))
                ReBuffer = bytearray()
                while True:
                    if (len(ReBuffer) >= self.MESSAGE_LEN):
                        buffer = ReBuffer[0:self.MESSAGE_LEN]
                        ReString = str(buffer, encoding="utf-8")
                        self.logging.info(self.tag + ": New Message!\n" + ReString)
                        ReBuffer = ReBuffer[self.MESSAGE_LEN:]
                        break
                    else:
                        recvBuffer = clientConnection.recv(self.MESSAGE_LEN)
                        ReBuffer[len(ReBuffer):] = recvBuffer
                sleep(self.SLEEP_TIME)
        except error as msg:
            self.logging.warning(self.tag + ": Closed Client Connection:%s!", msg)
        finally:
            clientConnection.close()
