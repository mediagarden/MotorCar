# -*- coding:utf-8 -*-
import threading
import os


# 拍照服务函数
# __cameraDemo：模拟拍照数据获取
class CameraDriver:
    cameraLock = threading.Lock()

    def __init__(self, logging):
        self.logging = logging
        self.tag = "Camera Driver"

    def camera(self):
        CameraDriver.cameraLock.acquire()
        self.logging.warning(self.tag + ":Camera Begin to Take Photo!")
        # TODO:开始拍照
        buffer = self.__cameraDemo()
        CameraDriver.cameraLock.release()
        return buffer

    def __cameraDemo(self):
        if (os.path.exists("Doraemon.jpg")):
            os.remove("Doraemon.jpg")
        os.system("fswebcam -d /dev/video0 -r 1080x720 --jpeg 100 -F 5 Doraemon.jpg")
        filename = "Default.jpg"
        if (os.path.exists("Doraemon.jpg")):
            filename = "Doraemon.jpg"
        self.logging.warning(self.tag + ":OpenFile %s!", filename)
        file = open(filename, 'rb+')
        fileBuffer = bytearray()
        while True:
            buffer = file.read()
            if (len(buffer) != 0):
                fileBuffer += buffer
            else:
                break
        file.close()
        self.logging.warning(self.tag + ":Camera Demo Function Return Demo Photo!")
        self.logging.warning(self.tag + ":The Photo Size :%s!", str(len(fileBuffer)))
        return fileBuffer
