# encoding='utf-8'

import logging
from time import ctime, sleep
import RPi.GPIO as GPIO

'''
REQUEST:
{
    "MESSAGE_ID": 11111,
    "CAR_CONTROL": {
        "ANGLE": 0.1,
        "RANGE": 0.85
    },
    "HANDS_CONTROL": {
        "MODE": "STANDBY||CONTROL",
        "ANGLE": [
            0,
            0,
            0
        ]
    }
}
RESPONSE:
{
    "MESSAGE_ID":11111,
    "STATUS":0
}
'''


class HandDriver:
    def __init__(self, logging):
        self.logging = logging
        self.tag = "Hand Control"
        self.HAND_PWM = 21
        self.MID_PWM = 20
        self.ROOT_PWM = 16

        self.preMode = "CONTROL"
        self.preHandAngle = -100
        self.preMidAngle = -100
        self.preRootAngle = -100

        self.mode = "STANDBY"
        self.handAngle = 0
        self.midAngle = 0
        self.rootAngle = 0

        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.HAND_PWM, GPIO.OUT)
        GPIO.setup(self.MID_PWM, GPIO.OUT)
        GPIO.setup(self.ROOT_PWM, GPIO.OUT)

        self.handPwm = GPIO.PWM(self.HAND_PWM, 50)
        self.midPwm = GPIO.PWM(self.MID_PWM, 50)
        self.rootPwm = GPIO.PWM(self.ROOT_PWM, 50)
        self.handPwm.start(00)
        self.midPwm.start(00)
        self.rootPwm.start(00)

    def __del__(self):
        self.HandRecovery()
        self.handPwm.stop()
        self.midPwm.stop()
        self.rootPwm.stop()
        GPIO.cleanup()

    def __pwm(self):
        if (not abs(self.preHandAngle - self.handAngle) < 1.0e-2):
            self.preHandAngle = self.handAngle
            angle = self.handAngle * 0.30 + 0.30
            self.handPwm.ChangeDutyCycle(7.5 + 5 * angle)
        else:
            self.handPwm.ChangeDutyCycle(00)
        if (not abs(self.preMidAngle - self.midAngle) < 1.0e-2):
            angle = (0.0 - self.midAngle) * 0.60 + (-0.10)
            self.midPwm.ChangeDutyCycle(7.5 + 5 * angle)
        else:
            self.midPwm.ChangeDutyCycle(00)
        if (not abs(self.preRootAngle - self.rootAngle) < 1.0e-2):
            self.preRootAngle = self.rootAngle
            angle = (0.0 - self.rootAngle) * 0.60 + (-0.34)
            self.rootPwm.ChangeDutyCycle(7.5 + 5 * angle)
        else:
            self.rootPwm.ChangeDutyCycle(00)

    def __pwm_remain(self):
        self.handPwm.ChangeDutyCycle(00)
        self.midPwm.ChangeDutyCycle(00)
        self.rootPwm.ChangeDutyCycle(00)

    def __pwm_standby(self):
        angle = 0.60
        self.handPwm.ChangeDutyCycle(7.5 + 5 * angle)
        angle = 0.70
        self.midPwm.ChangeDutyCycle(7.5 + 5 * angle)
        angle = -0.34
        self.rootPwm.ChangeDutyCycle(7.5 + 5 * angle)

    def __control(self):
        if (self.preMode == "STANDBY" and self.mode == "STANDBY"):
            self.preHandAngle = -100
            self.preMidAngle = -100
            self.preRootAngle = -100
            self.__pwm_remain()
        elif (self.preMode == "STANDBY" and self.mode == "CONTROL"):
            self.preHandAngle = -100
            self.preMidAngle = -100
            self.preRootAngle = -100
            self.__pwm()
        elif (self.preMode == "CONTROL" and self.mode == "STANDBY"):
            self.preHandAngle = -100
            self.preMidAngle = -100
            self.preRootAngle = -100
            self.__pwm_standby()
        elif (self.preMode == "CONTROL" and self.mode == "CONTROL"):
            self.__pwm()
        self.preMode = self.mode

    def HandRecovery(self):
        self.logging.info(self.tag + ": Hand Recovery!")
        self.__control()
        sleep(0.5)
        self.__control()

    def HandControl(self, msg):
        self.logging.info(self.tag + ": Hand Control!")
        self.mode = msg["HANDS_CONTROL"]["MODE"]
        self.rootAngle = msg["HANDS_CONTROL"]["ANGLE"][0]
        self.midAngle = msg["HANDS_CONTROL"]["ANGLE"][1]
        self.handAngle = msg["HANDS_CONTROL"]["ANGLE"][2]
        self.__control()
