package com.samsung.baymax.motorcar;

public interface IMotorCarCallback {
    public void motorCarCallback(String msg);
}
