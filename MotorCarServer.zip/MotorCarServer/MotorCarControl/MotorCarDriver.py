# encoding='utf-8'

import logging
from time import ctime, sleep
import RPi.GPIO as GPIO

'''
REQUEST:
{
    "MESSAGE_ID": 11111,
    "CAR_CONTROL": {
        "ANGLE": 0.1,
        "RANGE": 0.85
    },
    "HANDS_CONTROL": {
        "MODE": "STANDBY||CONTROL",
        "ANGLE": [
            0,
            0,
            0
        ]
    }
}
RESPONSE:
{
    "MESSAGE_ID":11111,
    "STATUS":0
}
'''


class MotorCarDriver:
    def __init__(self, logging):
        self.logging = logging
        self.tag = "MotorCar Control"
        self.LEFT_EN = 2
        self.LEFT_IN1 = 3
        self.LEFT_IN2 = 4

        self.RIGHT_EN = 10
        self.RIGHT_IN1 = 9
        self.RIGHT_IN2 = 11

        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.LEFT_EN, GPIO.OUT)
        GPIO.setup(self.LEFT_IN1, GPIO.OUT)
        GPIO.setup(self.LEFT_IN2, GPIO.OUT)
        GPIO.setup(self.RIGHT_EN, GPIO.OUT)
        GPIO.setup(self.RIGHT_IN1, GPIO.OUT)
        GPIO.setup(self.RIGHT_IN2, GPIO.OUT)
        self.leftPwm = GPIO.PWM(self.LEFT_EN, 50)
        self.rightPwm = GPIO.PWM(self.RIGHT_EN, 50)
        self.leftPwm.start(00)
        self.rightPwm.start(00)

    def __del__(self):
        self.leftPwm.stop()
        self.rightPwm.stop()
        GPIO.cleanup()

    def __pwm(self, wheel="ALL", direction="FORWARD", pwm=0):
        if (wheel == "ALL" or wheel == "LEFT"):
            if (direction == "FORWARD"):
                GPIO.output(self.LEFT_IN1, GPIO.LOW)
                GPIO.output(self.LEFT_IN2, GPIO.HIGH)
            else:
                GPIO.output(self.LEFT_IN1, GPIO.HIGH)
                GPIO.output(self.LEFT_IN2, GPIO.LOW)
            self.leftPwm.ChangeDutyCycle(pwm)
        if (wheel == "ALL" or wheel == "RIGHT"):
            if (direction == "FORWARD"):
                GPIO.output(self.RIGHT_IN1, GPIO.HIGH)
                GPIO.output(self.RIGHT_IN2, GPIO.LOW)
            else:
                GPIO.output(self.RIGHT_IN1, GPIO.LOW)
                GPIO.output(self.RIGHT_IN2, GPIO.HIGH)
            self.rightPwm.ChangeDutyCycle(pwm)

    def __forward(self, pwm):
        self.logging.info(self.tag + ": FORWARD!")
        if(pwm<90):
            pwm=pwm*0.5
        self.__pwm("ALL", "FORWARD", pwm)

    def __backward(self, pwm):
        self.logging.info(self.tag + ": BACKWARD!")
        if(pwm<90):
            pwm=pwm*0.5
        self.__pwm("ALL", "BACKWARD", pwm)

    def __leftforward(self, pwm):
        self.logging.info(self.tag + ": LEFT&FORWARD!")
        self.__pwm("LEFT", "BACKWARD", pwm * 0.25)
        self.__pwm("RIGHT", "FORWARD", pwm * 0.25)

    def __rightforward(self, pwm):
        self.logging.info(self.tag + ": RIGHT&FORWARD!")
        self.__pwm("LEFT", "FORWARD", pwm * 0.25)
        self.__pwm("RIGHT", "BACKWARD", pwm * 0.25)


    def MotorCarControl(self, msg):
        angle = msg["CAR_CONTROL"]["ANGLE"]
        range = msg["CAR_CONTROL"]["RANGE"]
        pwm_val = round(range * 100)
        if (pwm_val > 100):
            pwm_val = 100
        elif (pwm_val < 0):
            pwm_val = 0
        if (angle <= 0.125 or angle > 0.875):
            self.__forward(pwm_val)
        elif (angle > 0.125 and angle <= 0.375):
            self.__rightforward(pwm_val)
        elif (angle >= 0.375 and angle <= 0.625):
            self.__backward(pwm_val)
        elif (angle > 0.625 and angle <= 0.875):
            self.__leftforward(pwm_val)
